ALTER TABLE `product_distributor` ADD INDEX(`stock`);
ALTER TABLE `customers` ADD INDEX(`phone_number`);
ALTER TABLE `brand` ADD INDEX(`name`);
ALTER TABLE `product` ADD INDEX(`weight`);